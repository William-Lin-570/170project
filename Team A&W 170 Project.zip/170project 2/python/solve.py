"""Solves an instance.

Modify this file to implement your own solvers.

For usage, run `python3 solve.py --help`.
"""
import argparse
from cmath import inf
from pathlib import Path
from typing import Callable, Dict
from file_wrappers import StdinFileWrapper, StdoutFileWrapper
from instance import Instance
from point import Point
from solution import Solution
from GurobiDraft1 import gurobiClass

def solve_naive(instance: Instance) -> Solution:
    return gurobiClass.gurobiAttempt(instance)
    #return heuristic_greedy(instance)
    #return efficient_greedy(instance)
    #return solve_greedy(instance)
    '''
    return Solution(
        instance=instance,
        towers=instance.cities,
    )
    '''

def heuristic_greedy(instance):
    cities = instance.cities
    Rs = instance.coverage_radius
    Rp = instance.penalty_radius
    D = instance.grid_side_length
    countsDict = {}
    coveredCitiesDict = {}
    towersLst = []
    #create a set of coordinates that are within range Rs of a city
    # (ie. ignore all coords far from any cities)
    relevantCoordinates = set()
    for city in cities:
        for i in range(city.x-Rs, city.x+Rs+1):
            for j in range(city.y-Rs, city.y+Rs+1):
                if Point(i, j).distance_sq(city) <= Rs**2:
                    if 0 <= i < D and 0 <= j < D:
                        relevantCoordinates.add(Point(i, j))
    def getDistanceBetweenPoints(x1, y1, x2, y2):
        #calculates Euclidean distance between any 2 coordinates
        return ((x1-x2)**2 + (y1-y2)**2)**0.5
    def countcities(x, y, r, cities):
        #counts the number of cities within range Rs of a coordinate & returns those cities as a
        # list of Points
        citieslst = []
        count = 0
        for i in range(x-r, x+r+1):
            for j in range(y-r, y+r+1):
                if (Point(i, j) in cities) and (getDistanceBetweenPoints(i, j, x, y) <= r):
                    count += 1
                    citieslst.append(Point(i, j))
        return count, citieslst
    def getPenalty(x, y, towersLst, Rp):
        c = 0
        overlappingTowers = []
        #count number of existing towers within penalty range Rp of proposed tower at x, y
        for tower in towersLst:
            if x-Rp <= tower.x <= x+Rp and y-Rp <= tower.y <= y+Rp:
                c += 1
                overlappingTowers.append(tower)
        proposed_tower_penalty = 170*(2.718)**(0.17*c)
        return proposed_tower_penalty

    
    #set default max values; we want to track the coordinate with most cities in range
    #tracking max count and the associated cities that are in range for future removal
    # from consideration
    maxCoord = None
    maxCount = -1
    minPenalty = float("inf")
    maxCitiesLst = []
    for relevantCoord in relevantCoordinates:
        currentCount, currentCities = countcities(relevantCoord.x, relevantCoord.y, Rs, cities)
        penalty = getPenalty(relevantCoord.x, relevantCoord.y, towersLst, Rp)
        countsDict[relevantCoord] = currentCount
        coveredCitiesDict[relevantCoord] = currentCities
        if penalty <= minPenalty:
            if currentCount > maxCount:
                maxCoord = relevantCoord
                maxCitiesLst = currentCities
                minPenalty = penalty
    #if cities left in consideration is 0, we are done
    while len(cities) > 0:
        towersLst.append(maxCoord)
        #remove covered cities from consideration
        temp = [x for x in cities if x not in maxCitiesLst]
        cities = temp
        #update countsDict to reflect the removal of some cities
        #the placement of a tower can cover cities that were once covered by coordinates at most 2*Rs away
        for p in range(maxCoord.x-2*Rs, maxCoord.x+2*Rs+1):
            for q in range(maxCoord.y-2*Rs, maxCoord.y+2*Rs+1):
                if Point(p, q) in coveredCitiesDict:
                    temp = [x for x in coveredCitiesDict[Point(p, q)] if x not in maxCitiesLst]
                    coveredCitiesDict[Point(p, q)] = temp
                if Point(p, q) in countsDict:
                    countsDict[Point(p, q)] = len(coveredCitiesDict[Point(p, q)])
        #max coord is the key with the largest value in countsDict
        maxCoord = max(countsDict, key=countsDict.get)
        maxCitiesLst = coveredCitiesDict[maxCoord]

    return Solution(
        instance = instance,
        towers = towersLst
    )

def efficient_greedy(instance):
    cities = instance.cities
    Rs = instance.coverage_radius
    Rp = instance.penalty_radius
    D = instance.grid_side_length
    countsDict = {}
    coveredCitiesDict = {}
    towersLst = []
    #create a set of coordinates that are within range Rs of a city
    # (ie. ignore all coords far from any cities)
    relevantCoordinates = set()
    for city in cities:
        for i in range(city.x-Rs, city.x+Rs+1):
            for j in range(city.y-Rs, city.y+Rs+1):
                if Point(i, j).distance_sq(city) <= Rs**2:
                    if 0 <= i < D and 0 <= j < D:
                        relevantCoordinates.add(Point(i, j))
        '''
        for i in range(city.x-Rs, city.x+1):
            for j in range(city.y-Rs, city.y+1):
                if Point(i, j).distance_sq(city) <= Rs**2:
                    if 0 <= i < D and 0 <= j < D:
                        relevantCoordinates.add(Point(i, j))
                    if 0 <= i < D and 0<= 2*city.y-j < D:
                        relevantCoordinates.add(Point(i, 2*city.y-j))
                    if 0 <= 2*city.x-i < D and 0 <= 2*city.y-j < D:
                        relevantCoordinates.add(Point(2*city.x-i, 2*city.y-j))
                    if 0 <= 2*city.x-i < D and 0 <= j < D:
                        relevantCoordinates.add(Point(2*city.x-i, j))
        '''
    def getDistanceBetweenPoints(x1, y1, x2, y2):
        #calculates Euclidean distance between any 2 coordinates
        return ((x1-x2)**2 + (y1-y2)**2)**0.5
    def countcities(x, y, r, cities):
        #counts the number of cities within range Rs of a coordinate & returns those cities as a
        # list of Points
        citieslst = []
        count = 0
        for i in range(x-r, x+r+1):
            for j in range(y-r, y+r+1):
                if (Point(i, j) in cities) and (getDistanceBetweenPoints(i, j, x, y) <= r):
                    count += 1
                    citieslst.append(Point(i, j))
        return count, citieslst
    #set default max values; we want to track the coordinate with most cities in range
    #tracking max count and the associated cities that are in range for future removal
    # from consideration
    maxCoord = None
    maxCount = -1
    maxCitiesLst = []
    for relevantCoord in relevantCoordinates:
        currentCount, currentCities = countcities(relevantCoord.x, relevantCoord.y, Rs, cities)
        countsDict[relevantCoord] = currentCount
        coveredCitiesDict[relevantCoord] = currentCities
        if currentCount >= maxCount:
            maxCoord = relevantCoord
            maxCitiesLst = currentCities

    #if cities left in consideration is 0, we are done
    while len(cities) > 0:
        towersLst.append(maxCoord)
        #remove covered cities from consideration
        temp = [x for x in cities if x not in maxCitiesLst]
        cities = temp
        #update countsDict to reflect the removal of some cities
        #the placement of a tower can cover cities that were once covered by coordinates at most 2*Rs away
        for p in range(maxCoord.x-2*Rs, maxCoord.x+2*Rs+1):
            for q in range(maxCoord.y-2*Rs, maxCoord.y+2*Rs+1):
                if Point(p, q) in coveredCitiesDict:
                    temp = [x for x in coveredCitiesDict[Point(p, q)] if x not in maxCitiesLst]
                    coveredCitiesDict[Point(p, q)] = temp
                if Point(p, q) in countsDict:
                    countsDict[Point(p, q)] = len(coveredCitiesDict[Point(p, q)])
        #max coord is the key with the largest value in countsDict
        maxCoord = max(countsDict, key=countsDict.get)
        maxCitiesLst = coveredCitiesDict[maxCoord]

    return Solution(
        instance = instance,
        towers = towersLst
    )



    '''
    #repeat the below process until all cities have been covered by a tower (we remove a city from
    # consideration once it's been covered by a tower)
    while len(cities) > 0:
        #reset the maximum values
        maxCoord = None
        maxCount = -1
        maxCities = []
        #iterate through the relevant coordinates of the map
        for relevantCoord in relevantCoordinates:
            #populate a dictionary of the number of cities within range of every relevant
            # coordinate
                currentCount, currentCities = countcities(relevantCoord.x, relevantCoord.y, Rs, cities)
                countsDict[Point(i, j)] = currentCount
                #keep track of the coord with the most cities within range that we've seen
                if currentCount > maxCount:
                    maxCoord = Point(i, j)
                    maxCount = currentCount
                    maxCities = currentCities
        #once we're done iterating through the map, add the coord with most cities into our tower
        # list (greedy)
        towersLst.append(maxCoord)
        #print(maxCoord.x, maxCoord.y)
        #update cities to reflect the cities that have been taken out of consideration by the
        # construction of a tower
        #print(maxCities)
        temp = [x for x in cities if x not in maxCities]
        cities = temp
        #print(cities)
        #update the number of cities within range of all the coordinates near the proposed tower, as
        # some of their cities would have been taken out of consideration
        for p in range(i-2*Rs, i+2*Rs+1):
            for q in range(j-2*Rs, j+2*Rs+1):
                if Point(p, q) in relevantCoordinates:
                    currentCount, currentCities = countcities(p, q, Rs, cities)
                    countsDict[Point(p, q)] = currentCount
    return Solution(
        instance = instance,
        towers = towersLst
    )
    '''

def solve_greedy(instance):
    def getDistanceBetweenPoints(x1, y1, x2, y2):
        #calculates Euclidean distance between any 2 coordinates
        return ((x1-x2)**2 + (y1-y2)**2)**0.5
    def countcities(x, y, r, cities):
        #counts the number of cities within range Rs of a coordinate & returns those cities as a list of Points
        citieslst = []
        count = 0
        for i in range(x-r, x+r+1):
            for j in range(y-r, y+r+1):
                if (Point(i, j) in cities) and (getDistanceBetweenPoints(i, j, x, y) <= r):
                    count += 1
                    citieslst.append(Point(i, j))
        return count, citieslst
    cities = instance.cities
    Rs = instance.coverage_radius
    Rp = instance.penalty_radius
    D = instance.grid_side_length
    countsDict = {}
    towersLst = []
    #repeat the below process until all cities have been covered by a tower (we remove a city from
    # consideration once it's been covered by a tower)
    while len(cities) > 0:
        #reset the maximum values
        maxCoord = None
        maxCount = -1
        maxCities = []
        #iterate through the entire map
        for i in range(0, D):
            for j in range(0, D):
                #populate a dictionary of the number of cities within range of every possible
                # coordinate
                currentCount, currentCities = countcities(i, j, Rs, cities)
                #print(currentCount, currentCities)
                    #DEBUG
                    #if len(currentCities) > 0:
                    #    print(currentCities)
                    #if currentCount > 1:
                    #    print(currentCount)
                countsDict[Point(i, j)] = currentCount
                #keep track of the coord with the most cities within range that we've seen
                if currentCount > maxCount:
                    maxCoord = Point(i, j)
                    maxCount = currentCount
                    maxCities = currentCities
        #once we're done iterating through the map, add the coord with most cities into our tower
        # list (greedy)
        towersLst.append(maxCoord)
        #print(maxCoord.x, maxCoord.y)
        #update cities to reflect the cities that have been taken out of consideration by the
        # construction of a tower
        #print(maxCities)
        temp = [x for x in cities if x not in maxCities]
        cities = temp
        #print(cities)
        #update the number of cities within range of all the coordinates near the proposed tower, as
        # some of their cities would have been taken out of consideration
        for p in range(i-2*Rs, i+2*Rs+1):
            for q in range(j-2*Rs, j+2*Rs+1):
                currentCount, currentCities = countcities(p, q, Rs, cities)
                countsDict[Point(p, q)] = currentCount
    return Solution(
        instance = instance,
        towers = towersLst
    )

SOLVERS: Dict[str, Callable[[Instance], Solution]] = {
    "naive": solve_naive
}


# You shouldn't need to modify anything below this line.
def infile(args):
    if args.input == "-":
        return StdinFileWrapper()

    return Path(args.input).open("r")


def outfile(args):
    if args.output == "-":
        return StdoutFileWrapper()

    return Path(args.output).open("w")


def main(args):
    with infile(args) as f:
        instance = Instance.parse(f.readlines())
        solver = SOLVERS[args.solver]
        solution = solver(instance)
        assert solution.valid()
        with outfile(args) as g:
            print("# Penalty: ", solution.penalty(), file=g)
            solution.serialize(g)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Solve a problem instance.")
    parser.add_argument("input", type=str, help="The input instance file to "
                        "read an instance from. Use - for stdin.")
    parser.add_argument("--solver", required=True, type=str,
                        help="The solver type.", choices=SOLVERS.keys())
    parser.add_argument("output", type=str,
                        help="The output file. Use - for stdout.",
                        default="-")
    main(parser.parse_args())
