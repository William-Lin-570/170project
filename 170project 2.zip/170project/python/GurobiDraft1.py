#!/usr/bin/env python
# coding: utf-8

# In[1]:


from gurobi import *
import gurobipy as gp
from gurobipy import GRB
import argparse
from cmath import inf
from pathlib import Path
from typing import Callable, Dict
from file_wrappers import StdinFileWrapper, StdoutFileWrapper
from instance import Instance
from point import Point
from solution import Solution


# In[2]:


m = Model()


# In[8]:


class gurobiClass():
    def gurobiAttempt(instance):
        cities = instance.cities
        Rs = instance.coverage_radius
        D = instance.grid_side_length
        citiesDict = dict(zip(range(instance.N()), cities))
        regions, population = gp.multidict(dict(zip(range(instance.N()), [1 for _ in range(instance.N())])))
        planeCovers = {}
        for i in range(D):
            for j in range(D):
                planeCovers[D*i+j] = set()
                for city in cities:
                    if (cities[city][0] - i)**2 + (cities[city][1] - j)**2 <= Rs**2:
                        temp = planeCovers[D*i+j]
                        temp.add(city)
                        planeCovers[D*i+j] = temp               
        for key in planeCovers:
            planeCovers[key] = [planeCovers[key], 1]
        sites, coverage, cost = gp.multidict(planeCovers)

        budget = instance.N()
        percentage = 100
        towerlst = []
        while percentage == 100:
            # MIP  model formulation
            m = gp.Model("cell_tower")
            build = m.addVars(len(sites), vtype=GRB.BINARY, name="Build")
            is_covered = m.addVars(len(regions), vtype=GRB.BINARY, name="Is_covered")
            m.addConstrs((gp.quicksum(build[t] for t in sites if r in coverage[t]) >= is_covered[r]
                                    for r in regions), name="Build2cover")
            m.addConstr(build.prod(cost) <= budget, name="budget")
            m.setObjective(is_covered.prod(population), GRB.MAXIMIZE)
            m.optimize()
            total_population = 0
            for region in range(len(regions)):
                total_population += population[region]
            percentage = round(100*m.objVal/total_population, 2)
            if percentage == 100:
                towerlst = build.keys()
                budget -= 1
        returnTowers = [citiesDict[x] for x in towerlst]
        return Solution(
            instance = instance,
            towers = returnTowers
        )